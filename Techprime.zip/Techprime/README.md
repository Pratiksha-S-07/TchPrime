![Screenshot 2024-04-08 135201](https://github.com/omkarbhalekar9/projectmanager/assets/151622699/798cabae-910c-41ed-b4da-5ae14cf20ef2)
![Screenshot 2024-04-08 135227](https://github.com/omkarbhalekar9/projectmanager/assets/151622699/305bd4ff-a9eb-4e6d-a66e-50e521c7df9a)
![Screenshot 2024-04-08 135122](https://github.com/omkarbhalekar9/projectmanager/assets/151622699/d9cac6bd-0d93-480d-86a2-6e7dcf877461)
![Screenshot 2024-04-08 135144](https://github.com/omkarbhalekar9/projectmanager/assets/151622699/8ee350d8-a72c-45bb-95f5-85f974f331d0)

This project management system aims to streamline project management processes, improve collaboration among team members, and provide insights into project progress through intuitive interfaces and robust functionalities.
