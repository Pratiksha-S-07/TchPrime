package com.techprime;

public class Constants {

	public static final int STATUS_REGISTERED = 1;
	public static final int STATUS_RUNNING = 2;
	public static final int STATUS_CANCELLED = 3;
	public static final int STATUS_CLOSED = 4;

}
