package com.techprime;


public class ProjectManager 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
